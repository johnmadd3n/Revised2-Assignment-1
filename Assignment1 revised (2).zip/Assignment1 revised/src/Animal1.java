public interface Animal1 {
    String makeSound();
    String whatAmi();

}
